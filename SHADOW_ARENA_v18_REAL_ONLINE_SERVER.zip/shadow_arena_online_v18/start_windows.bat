@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 22 or newer is required: https://nodejs.org
  pause
  exit /b 1
)
echo.
echo SHADOW ARENA v18 server
set "PORT=3000"
echo Open http://localhost:%PORT% in your browser
start "" "http://localhost:%PORT%"
node server.js
if errorlevel 1 (
  echo.
  echo Could not start server. Please check whether port 3000 is already in use.
  pause
)
