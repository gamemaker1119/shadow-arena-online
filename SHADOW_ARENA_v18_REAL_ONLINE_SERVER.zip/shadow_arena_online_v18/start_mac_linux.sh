#!/bin/sh
set -eu
cd "$(dirname "$0")"
: "${PORT:=3000}"
export PORT
echo "SHADOW ARENA v18 at http://localhost:$PORT"
exec node server.js
