'use strict';
const assert=require('node:assert/strict');
const {Arena,C,TYPES,WALLS}=require('./engine');
const {spawn}=require('node:child_process');
const http=require('node:http');
const net=require('node:net');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const port=()=>new Promise(resolve=>{const n=net.createServer();n.listen(0,'127.0.0.1',()=>{const p=n.address().port;n.close(()=>resolve(p));});});
const send=(ws,o)=>ws.send(JSON.stringify(o));
function inbox(sock){
 const q=[],pending=[];
 sock.addEventListener('message',ev=>{
  let m;try{m=JSON.parse(ev.data);}catch{return;}
  const idx=pending.findIndex(p=>p.test(m));
  if(idx>=0){const w=pending.splice(idx,1)[0];clearTimeout(w.timer);w.resolve(m);}
  else{q.push(m);if(q.length>300)q.shift();}
 });
 return async(test,ms=4000)=>{
  const i=q.findIndex(test);if(i>=0)return q.splice(i,1)[0];
  return new Promise((resolve,reject)=>{
   const req={test,resolve,reject,timer:null};req.timer=setTimeout(()=>{const at=pending.indexOf(req);if(at>=0)pending.splice(at,1);reject(Error('Message timeout: '+JSON.stringify(q.slice(-6).map(v=>v.type))));},ms);pending.push(req);
  });
 };
}
async function connect(addr){
 const sock=new WebSocket(addr);
 await new Promise((resolve,reject)=>{sock.addEventListener('open',resolve,{once:true});sock.addEventListener('error',reject,{once:true});});
 return {sock,recv:inbox(sock)};
}
async function main(){
 // Unit tests for gameplay and cooldown integrity.
 assert.equal(TYPES.length,13);
 for(const type of TYPES){
  const g=new Arena([type,'physics']);
  g.setInput(0,{mx:0,my:0,fire:true,aimX:775,aimY:300,special:true});g.tick(33);
  assert(g.bullets.length>0,'Attack missing: '+type);
  const before=g.players[0].specialCooldown;
  g.setInput(0,{special:true});g.tick(33);assert(g.players[0].specialCooldown>0&&g.players[0].specialCooldown<before,'cooldown '+type);
  g.players[0].ultCharge=100;g.setInput(0,{ult:true,aimX:775,aimY:300});g.tick(33);
  assert.equal(g.players[0].ultCharge,0,'ultimate '+type);
 }
 console.log('PASS: 13 fighters, basic attack, special cooldown and ultimate');
 const p=await port();const proc=spawn(process.execPath,['server.js'],{cwd:__dirname,env:{...process.env,PORT:String(p),RECONNECT_MS:'5000'},stdio:['ignore','pipe','pipe']});
 let logs='';proc.stderr.on('data',b=>logs+=b);proc.stdout.on('data',b=>logs+=b);
 try{
  let healthy=false;
  for(let i=0;i<100;i++){try{let res=await fetch(`http://127.0.0.1:${p}/health`);if(res.ok){let a=await res.json();healthy=a.ok&&a.version==='18.0';if(healthy)break;}}catch{}await sleep(40);}
  assert(healthy,'health endpoint');
  const html=await fetch(`http://127.0.0.1:${p}/`);assert(html.ok);assert.match(await html.text(),/copyInvite/);
  assert.equal((await fetch(`http://127.0.0.1:${p}/server.js`)).status,404);
  const addr=`ws://127.0.0.1:${p}/ws`;
  const a=await connect(addr);send(a.sock,{type:'create',character:'math'});
  const sa=await a.recv(m=>m.type==='session');const l=await a.recv(m=>m.type==='lobby');
  assert.equal(sa.code,l.code);assert.match(l.code,/^[A-HJ-NP-Z2-9]{6}$/);
  const b=await connect(addr);send(b.sock,{type:'join',code:l.code,character:'bio'});
  const sb=await b.recv(m=>m.type==='session');assert.equal(sb.side,1);
  await a.recv(m=>m.type==='start');await b.recv(m=>m.type==='start');
  const first=await a.recv(m=>m.type==='state');assert.equal(first.data.players.length,2);
  const before=first.data.players[0].x;
  for(let i=0;i<10;i++){send(a.sock,{type:'input',data:{mx:1,my:0,aimX:800,aimY:300,fire:true,special:false,ult:false,dash:false,hp:1000000000}});await sleep(50);}
  const moving=await a.recv(m=>m.type==='state'&&m.data.players[0].x>before+2);
  assert(moving.data.players[0].hp<=C.math.hp,'authoritative HP');
  console.log('PASS: HTTP, real WebSocket lobby, two clients, movement, server-owned HP');
  const pa=a.recv(m=>m.type==='paused',3500);
  b.sock.close();await pa;
  const r=await connect(addr);send(r.sock,{type:'resume',code:sb.code,token:sb.token});
  await r.recv(m=>m.type==='session');await r.recv(m=>m.type==='start'&&m.resume);await a.recv(m=>m.type==='resumed');
  console.log('PASS: mid-game disconnect, pause, authenticated resume, resumed match');
  // Changed char, invented invalid movement, unauthorized room codes cannot mutate the match.
  send(r.sock,{type:'input',data:{mx:1e80,my:0,aimX:800,aimY:300,fire:true,special:true,ult:true,dash:true,hp:0,damage:999999}});
  send(r.sock,{type:'create',character:'cs'});
  await r.recv(m=>m.type==='error');
  // Explicit leave forfeits, frees a slot; the waiting player accepts a new friend.
  send(r.sock,{type:'leave'});
  await a.recv(m=>m.type==='opponent_left');
  const c=await connect(addr);send(c.sock,{type:'join',code:sa.code,character:'pe'});
  await c.recv(m=>m.type==='session');await c.recv(m=>m.type==='start');await a.recv(m=>m.type==='start');
  console.log('PASS: invalid input ignored, explicit leave, reusable room and new game');
  const pause=a.recv(m=>m.type==='paused');c.sock.close();await pause;
  await a.recv(m=>m.type==='opponent_left',9000);
  console.log('PASS: reconnect timeout eventually releases slot');
  a.sock.close();r.sock.close();
  // Room capacity and origin validation should reject inappropriate new handshakes.
  const h=await fetch(`http://127.0.0.1:${p}/health`);assert.equal(h.status,200);
  assert(!logs.includes('Message failure'),'unhandled protocol error: '+logs);
  console.log('PASS: server remains healthy after disconnect/reconnect and invalid packet tests');
 }finally{
  proc.kill('SIGTERM');await new Promise(r=>{if(proc.exitCode!==null||proc.signalCode!==null)r();else {proc.on('exit',r);setTimeout(r,2000);}});
 }
}
main().catch(e=>{console.error(e.stack||e);process.exitCode=1;});
