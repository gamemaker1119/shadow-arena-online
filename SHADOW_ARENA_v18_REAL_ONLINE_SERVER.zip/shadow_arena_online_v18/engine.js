'use strict';
// Authoritative online 1v1 combat engine. All coordinates/damage/cooldowns live here.
const C = require('./characters.json');
const WIDTH=900,HEIGHT=600,FRAME=1000/60;
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const walls0=[{x:195,y:145,w:65,h:30},{x:325,y:160,w:48,h:48},{x:320,y:440,w:48,h:48}];
const WALLS=[...walls0,...walls0.map(a=>({...a,x:WIDTH-a.x-a.w})),{x:424,y:270,w:52,h:32}];
function hitsWall(x,y,r){return WALLS.some(w=>{let dx=x-clamp(x,w.x,w.x+w.w),dy=y-clamp(y,w.y,w.y+w.h);return dx*dx+dy*dy<r*r;});}
function segmentPointDistSq(x0,y0,x1,y1,x,y){const dx=x1-x0,dy=y1-y0,v=(dx*dx+dy*dy)||1,t=clamp(((x-x0)*dx+(y-y0)*dy)/v,0,1);return (x-(x0+dx*t))**2+(y-(y0+dy*t))**2;}
function move(f,dx,dy){let steps=Math.max(1,Math.ceil(Math.hypot(dx,dy)/3));for(let i=0;i<steps;i++){let x=clamp(f.x+dx/steps,f.r,WIDTH-f.r),y=clamp(f.y+dy/steps,f.r,HEIGHT-f.r);if(!hitsWall(x,f.y,f.r))f.x=x;if(!hitsWall(f.x,y,f.r))f.y=y;}}
const PROJECTILE={math:['diamond',6.6],physics:['hex',6.5],chem:['orb',5.2],bio:['petal',4],english:['arrow',10.5],history:['square',5.8],earth:['rock',4.3],cs:['pixel',8.8],korean:['wave',6],ethics:['shield',3.8],art:['star',5.6],music:['note',6.4],pe:['bolt',7.2]};
const TYPES=Object.keys(C);
function player(type,side){let c=C[type];return {side,type,x:side===0?125:775,y:300,r:17,hp:c.hp,max:c.hp,level:1,xp:0,nextXP:100,inv:0,slow:0,stun:0,shield:0,ultCharge:0,specialCooldown:0,dashCooldown:0,boost:0,regen:0,lastShot:-1e5,dead:false,jumpHeight:0,vx:0,vy:0};}
class Arena {
  constructor(types){if(types.some(t=>!C[t])||types.length!==2)throw Error('Bad fighter');this.players=types.map((t,i)=>player(t,i));this.input=[{},{},];this.bullets=[];this.areas=[];this.effects=[];this.pickups=[];this.time=0;this.seq=0;this.ended=false;this.winner=null;this.endReason='';this.startAt=Date.now();this.pickupClock=0;}
  setInput(side,input){if(this.ended)return;let p=this.input[side]||{};const n=v=>Number.isFinite(v)?clamp(v,-1,1):0;
    this.input[side]={mx:n(input.mx),my:n(input.my),aimX:Number.isFinite(input.aimX)?clamp(input.aimX,0,WIDTH):null,aimY:Number.isFinite(input.aimY)?clamp(input.aimY,0,HEIGHT):null,fire:!!input.fire,special:!!input.special||!!p.special,dash:!!input.dash||!!p.dash,ult:!!input.ult||!!p.ult};
  }
  foe(side){return this.players[1-side]}
  emit(f,ang,speed,damage,extra={}){if(this.bullets.length>=180)return;const radius=extra.radius||7;this.bullets.push({x:f.x+Math.cos(ang)*Math.max(22,radius+11),y:f.y+Math.sin(ang)*Math.max(22,radius+11),vx:Math.cos(ang)*speed,vy:Math.sin(ang)*speed,damage,owner:f.side,type:f.type,radius,life:extra.life||70,shape:extra.shape||PROJECTILE[f.type][0],color:extra.color||C[f.type].color,pierce:0,...extra,hitOnce:false,hitTargets:[]});}
  basic(f,a){let c=C[f.type],d=c.damage*(f.boost>0?1.65:1),em=(ang,speed,damage,extra={})=>this.emit(f,ang,speed,damage,{life:c.range/speed,...extra});
    switch(f.type){
      case'math':em(a,6.6,d*1.2,{radius:8});break;
      case'physics':for(let i=-3;i<=3;i++)em(a+i*.115,6.5,d*(i===0?.58:.34),{radius:6,pellet:true,knockback:i===0?18:8});break;
      case'chem':em(a,5.2,d*.72,{radius:9,acid:true,splash:true});break;
      case'bio':em(a,4,d*1.05,{radius:9,homing:true,healOwner:2});break;
      case'english':em(a,10.5,d*.92,{radius:5,pierce:3});break;
      case'history':em(a,5.8,d*.85,{radius:9,delayedMine:true,splash:true});break;
      case'earth':em(a,4.3,d*1.15,{radius:13,splash:true,knockback:22});break;
      case'cs':em(a,8.8,d*.72,{radius:6,glitch:true});break;
      case'korean':for(let j=-1;j<=1;j++)em(a+j*.2,6,d*.62,{radius:8,pierce:1,wave:true});break;
      case'ethics':em(a,3.8,d*1.3,{radius:11,knockback:20});break;
      case'art':em(a,5.6,d*.8,{radius:10,splash:true,paint:true});break;
      case'music':for(let j=-2;j<=2;j++)em(a+j*.19,6.4,d*.52,{radius:8,wave:true,pierce:1});break;
      case'pe':em(a,7.2,d*1.1,{life:Math.min(c.range,260)/7.2,radius:10,knockback:28});break;
    }
  }
  special(f,a){let em=(ang,sp,d,ex={})=>this.emit(f,ang,sp,d,{life:75,radius:9,...ex});switch(f.type){
    case'math':for(let j=-1;j<=1;j++)em(a+j*.12,5.7,17,{shape:'diamond',homing:j===0});break;
    case'physics':for(let j=-1;j<=1;j++)em(a+j*.25,4.2,19,{shape:'hex',radius:13,knockback:26,life:65});break;
    case'chem':em(a,5,10,{acid:true,splash:true,radius:11});break;
    case'bio':for(let j=-1;j<=1;j++)em(a+j*.18,4.4,12,{shape:'petal',homing:true,healOwner:5});break;
    case'english':for(let j=-1;j<=0;j++)em(a+j*.07,12,12,{shape:'arrow',radius:5,pierce:3,life:52});break;
    case'history':em(a,4.6,13,{delayedMine:true,splash:true,life:82});break;
    case'earth':for(let j=-1;j<=1;j+=2)em(a+j*.14,4,16,{radius:14,splash:true,knockback:25});break;
    case'cs':for(let j=-1;j<=1;j++)em(a+j*.10,9,9,{radius:6,glitch:true,life:58});break;
    case'korean':for(let j=-1;j<=1;j++)em(a+j*.27,5.3,13,{radius:10,wave:true,pierce:2});break;
    case'ethics':em(a,3.4,23,{radius:14,knockback:45,life:88});break;
    case'art':for(let j=-2;j<=2;j++)em(a+j*.2,5.2,10,{radius:11,paint:true,splash:true,life:68});break;
    case'music':for(let j=-1;j<=1;j++)em(a+j*.16,5.4+(j+1)*.9,14,{radius:8,knockback:j===0?24:0});break;
    case'pe':em(a,8.5,21,{radius:12,knockback:38,life:42});break;
  }}
  ultimate(f,a){let em=(ang,sp,d,ex={})=>this.emit(f,ang,sp,d,{life:100,radius:10,...ex});switch(f.type){
    case'math':for(let i=-3;i<=3;i++)em(a+i*.09,6.2,31,{shape:'diamond',homing:i===0});break;
    case'physics':for(let i=-1;i<=1;i++)em(a+i*.22,3.8,44,{shape:'hex',radius:17,knockback:68,life:115});break;
    case'chem':for(let i=-2;i<=2;i++)em(a+i*.18,5.1,22,{acid:true,splash:true,radius:12});break;
    case'bio':for(let i=0;i<8;i++)em(a+(i-3.5)*.24,4,19,{homing:true,healOwner:4,shape:'petal',radius:9,life:120});break;
    case'english':for(let i=-4;i<=4;i++)em(a+i*.055,13.5,24,{shape:'arrow',radius:6,pierce:4,life:90});break;
    case'history':for(let i=-2;i<=2;i++)em(a+i*.16,4.5,27,{shape:'square',radius:12,delayedMine:true,splash:true,life:115});break;
    case'earth':for(let i=-1;i<=1;i++)em(a+i*.2,3.5,36,{shape:'rock',radius:18,splash:true,knockback:42,life:120});break;
    case'cs':for(let i=-5;i<=5;i++)em(a+i*.10,10.8,18,{shape:'pixel',radius:7,glitch:i%2===0,pierce:1,life:85});break;
    case'korean':for(let i=-2;i<=2;i++)em(a+i*.17,7,29,{shape:'wave',radius:13,pierce:3,wave:true,life:105});break;
    case'ethics':for(let i=-1;i<=1;i+=2)em(a+i*.08,3.2,48,{shape:'shield',radius:17,knockback:72,life:125});break;
    case'art':for(let i=0;i<12;i++)em(a+(i-5.5)*.12,5.6,23,{shape:'star',radius:12,paint:true,splash:true});break;
    case'music':for(let i=-5;i<=5;i++)em(a+i*.11,7-Math.abs(i)*.35,26,{shape:'note',pierce:2,knockback:i===0?34:0});break;
    case'pe':for(let i=-1;i<=1;i++)em(a+i*.13,9,38,{shape:'bolt',radius:13,knockback:55,life:75});break;
  }this.fx(f.x,f.y,C[f.type].color,28);}
  fx(x,y,color,radius=20){this.effects.push({x,y,color,radius,t:22});if(this.effects.length>35)this.effects.shift();}
  area(owner,x,y,radius,damage,delay=10,color='#fd9372',kind='blast'){this.areas.push({owner,x,y,radius,damage,delay,kind,color,done:false,active:18,hit:false});if(this.areas.length>30)this.areas.shift();}
  harm(f,damage,attacker){if(f.hp<=0||f.inv>0)return false;
    let dmg=damage;if(f.type==='history')dmg*=.85;if(f.type==='earth'||f.type==='ethics')dmg*=.9;if(f.shield>0)dmg*=.5;
    f.hp=Math.max(0,f.hp-dmg);f.inv=8;this.fx(f.x,f.y,f.side===0?'#d9fdff':'#ff7782',16);
    if(attacker!=null&&attacker!==f.side){const a=this.players[attacker];a.ultCharge=clamp(a.ultCharge+Math.min(35,dmg*1.65+2),0,100);a.xp+=Math.max(1,Math.ceil(dmg*.4));if(a.xp>=a.nextXP){a.xp-=a.nextXP;a.level+=1;a.nextXP=Math.floor(a.nextXP*1.33);}}
    if(f.hp<=0){f.dead=true;this.ended=true;this.winner=1-f.side;this.endReason='KO';}return true;
  }
  areaTick(frames){for(let i=this.areas.length-1;i>=0;i--){let a=this.areas[i];if(!a.done){a.delay-=frames;if(a.delay<=0){a.done=true;a.active=18;const f=this.foe(a.owner);if(f.hp>0&&Math.hypot(f.x-a.x,f.y-a.y)<=a.radius+f.r)this.harm(f,a.damage,a.owner);this.fx(a.x,a.y,a.color,a.radius);}}
   else{a.active-=frames;if(a.active<=0)this.areas.splice(i,1);}}
  }
  shotTick(frames){for(let i=this.bullets.length-1;i>=0;i--){let z=this.bullets[i],oldX=z.x,oldY=z.y;
      if(z.homing){let target=this.foe(z.owner);if(target.hp>0){let ang=Math.atan2(target.y-z.y,target.x-z.x),current=Math.atan2(z.vy,z.vx),delta=Math.atan2(Math.sin(ang-current),Math.cos(ang-current)),speed=Math.hypot(z.vx,z.vy),next=current+clamp(delta,-.045*frames,.045*frames);z.vx=Math.cos(next)*speed;z.vy=Math.sin(next)*speed;}}
      z.x+=z.vx*frames;z.y+=z.vy*frames;z.life-=frames;
      let wall=WALLS.some(w=>{let ex0=w.x-z.radius,ey0=w.y-z.radius,ex1=w.x+w.w+z.radius,ey1=w.y+w.h+z.radius;let steps=Math.max(1,Math.ceil(Math.hypot(z.x-oldX,z.y-oldY)/4));for(let j=0;j<=steps;j++){let tx=oldX+(z.x-oldX)*j/steps,ty=oldY+(z.y-oldY)*j/steps;if(tx>ex0&&tx<ex1&&ty>ey0&&ty<ey1)return true;}return false;});
      const f=this.foe(z.owner);let contact=f.hp>0&&!z.hitTargets.includes(f.side)&&segmentPointDistSq(oldX,oldY,z.x,z.y,f.x,f.y)<=(f.r+z.radius)**2;
      if(contact){const landed=this.harm(f,z.damage,z.owner);if(landed){z.hitTargets.push(f.side);if(z.knockback){let d=Math.hypot(z.vx,z.vy)||1;move(f,z.vx/d*z.knockback,z.vy/d*z.knockback);}if(z.glitch)f.slow=Math.max(f.slow,45);if(z.healOwner){const source=this.players[z.owner];source.hp=Math.min(source.max,source.hp+z.healOwner);}if(z.acid)this.area(z.owner,f.x,f.y,44,z.damage*.55,10,z.color,'cloud');else if(z.splash)this.area(z.owner,f.x,f.y,34,z.damage*.40,5,z.color);}if(!z.pierce)wall=true;else z.pierce--;}
      if(wall||z.life<=0||z.x<-24||z.y<-24||z.x>WIDTH+24||z.y>HEIGHT+24){if(z.delayedMine)this.area(z.owner,clamp(z.x,0,WIDTH),clamp(z.y,0,HEIGHT),56,z.damage*1.2,28,z.color,'blast');else if(z.acid&&!contact)this.area(z.owner,clamp(z.x,0,WIDTH),clamp(z.y,0,HEIGHT),44,z.damage*.7,7,z.color,'cloud');else if(z.splash&&!contact)this.area(z.owner,clamp(z.x,0,WIDTH),clamp(z.y,0,HEIGHT),30,z.damage*.4,5,z.color);this.bullets.splice(i,1);}
    }}
  tick(ms=1000/30){if(this.ended)return;ms=clamp(ms,1,50);this.time+=ms;this.seq++;const fr=ms/FRAME;
    if(this.time>=180000){this.ended=true;this.endReason='TIME';this.winner=this.players[0].hp/this.players[0].max===this.players[1].hp/this.players[1].max?null:(this.players[0].hp/this.players[0].max>this.players[1].hp/this.players[1].max?0:1);return;}
    for(let s=0;s<2;s++){let f=this.players[s],inp=this.input[s]||{},other=this.foe(s);if(!f||f.hp<=0)continue;
      f.inv=Math.max(0,f.inv-fr);f.slow=Math.max(0,f.slow-fr);f.stun=Math.max(0,f.stun-fr);f.shield=Math.max(0,f.shield-fr);f.dashCooldown=Math.max(0,f.dashCooldown-ms);f.specialCooldown=Math.max(0,f.specialCooldown-ms);f.boost=Math.max(0,f.boost-ms);
      if(f.type==='bio'){f.regen+=ms;while(f.regen>=1000){f.regen-=1000;f.hp=Math.min(f.max,f.hp+2);}}
      let mx=inp.mx||0,my=inp.my||0,n=Math.hypot(mx,my);if(n>1){mx/=n;my/=n;}let a=Math.atan2((inp.aimY??other.y)-f.y,(inp.aimX??other.x)-f.x);
      if(inp.dash&&f.dashCooldown<=0){let dx=mx,dy=my;if(Math.hypot(dx,dy)<.15){dx=Math.cos(a);dy=Math.sin(a);}move(f,dx*125,dy*125);f.dashCooldown=4200;f.inv=Math.max(f.inv,16);this.fx(f.x,f.y,'#8ceaff',30);}
      if(f.stun<=0){let oldX=f.x,oldY=f.y;move(f,mx*C[f.type].speed*.66*(f.slow>0?.45:1)*fr,my*C[f.type].speed*.66*(f.slow>0?.45:1)*fr);f.vx=f.x-oldX;f.vy=f.y-oldY;
        if(inp.fire&&this.time-f.lastShot>=C[f.type].rate*2.4){f.lastShot=this.time;this.basic(f,a);}
        if(inp.special&&f.specialCooldown<=0){f.specialCooldown=5000;this.special(f,a);}
        if(inp.ult&&f.ultCharge>=100){f.ultCharge=0;this.ultimate(f,a);}
      }inp.dash=false;inp.special=false;inp.ult=false;
    }
    this.shotTick(fr);this.areaTick(fr);this.effects.forEach(e=>e.t-=fr);this.effects=this.effects.filter(e=>e.t>0);
  }
  snapshot(){return {seq:this.seq,elapsed:this.time,ended:this.ended,winner:this.winner,endReason:this.endReason,players:this.players.map(f=>({side:f.side,type:f.type,x:+f.x.toFixed(1),y:+f.y.toFixed(1),r:f.r,hp:+f.hp.toFixed(1),max:f.max,inv:f.inv,slow:f.slow,level:f.level,xp:f.xp,nextXP:f.nextXP,ultCharge:+f.ultCharge.toFixed(1),specialCooldown:Math.ceil(f.specialCooldown),dashCooldown:Math.ceil(f.dashCooldown),dead:f.dead})),shots:this.bullets.map(z=>({x:+z.x.toFixed(1),y:+z.y.toFixed(1),vx:z.vx,vy:z.vy,type:z.type,owner:z.owner,shape:z.shape,color:z.color,radius:z.radius})),effects:this.effects,areas:this.areas.map(a=>({x:a.x,y:a.y,radius:a.radius,color:a.color,kind:a.kind,done:a.done,active:a.active}))};}
}
module.exports={Arena,C,TYPES,WALLS};
