'use strict';
/** SHADOW ARENA v18 - authoritative match server with reconnectable WebSockets.
 * No third-party packages. Node 22+ (tests use the built-in WebSocket).
 * Suitable for a single Node process. Sticky routing / Redis would be required for >1 process.
 */
const http = require('node:http');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const { performance } = require('node:perf_hooks');
const { Arena, C } = require('./engine');
const PORT = Number(process.env.PORT ?? 3000);
const HOST = process.env.HOST || '0.0.0.0';
const MAX_ROOMS = Math.max(1, Math.min(500, Number(process.env.MAX_ROOMS) || 100));
const MAX_CONNECTIONS = Math.max(2, Math.min(2000, Number(process.env.MAX_CONNECTIONS) || 300));
const RECONNECT_MS = Math.max(5000, Math.min(120000, Number(process.env.RECONNECT_MS) || 30000));
const WAIT_MS = 15 * 60 * 1000;
const ENDED_MS = 10 * 60 * 1000;
const PLAY_MS = 5 * 60 * 1000;
const MAX_FRAME = 8192;
const INDEX = path.join(__dirname, 'index.html');
const rooms = new Map();
const sockets = new Set();
const ipCounts = new Map();
const perIpLimit = 10;
let closing = false;
let packetsRejected = 0;
const now = () => Date.now();
const validChar = c => typeof c === 'string' && Object.hasOwn(C, c);
const sendJSON = (conn, obj) => {
  if (!conn || conn.closed || conn.socket.destroyed || !conn.socket.writable) return;
  // Prevent slow clients from growing an unbounded queue.
  if (conn.socket.writableLength > 256 * 1024) return;
  let payload = Buffer.from(JSON.stringify(obj));
  let header;
  if (payload.length <= 125) header = Buffer.from([0x81, payload.length]);
  else if (payload.length <= 65535) {
    header = Buffer.alloc(4);header[0] = 0x81;header[1] = 126;header.writeUInt16BE(payload.length, 2);
  } else return;
  try { conn.socket.write(Buffer.concat([header, payload])); } catch { closeConn(conn); }
};
const sendRaw = (conn, opcode, data = Buffer.alloc(0)) => {
  if (conn.closed || conn.socket.destroyed || data.length > 125) return;
  try { conn.socket.write(Buffer.concat([Buffer.from([0x80 | opcode, data.length]), data])); } catch { closeConn(conn); }
};
const respond = (res, status, text, type='text/plain; charset=utf-8') => {
  res.writeHead(status, {'Content-Type': type, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff'});
  res.end(text);
};
const server = http.createServer((req, res) => {
  if (!['GET','HEAD'].includes(req.method)) return respond(res,405,'Method not allowed');
  let pathname;
  try { pathname = new URL(req.url, 'http://localhost').pathname; } catch { return respond(res,400,'Invalid URL'); }
  if (pathname === '/health' || pathname === '/ready') return respond(res, 200, JSON.stringify({ok: !closing, version:'18.0', rooms:rooms.size, connections:sockets.size}), 'application/json; charset=utf-8');
  if (pathname !== '/' && pathname !== '/index.html') return respond(res, 404, 'Not found');
  res.writeHead(200, {
    'Content-Type':'text/html; charset=utf-8', 'Cache-Control':'no-store', 'X-Content-Type-Options':'nosniff',
    'Referrer-Policy':'same-origin',
    'Content-Security-Policy':"default-src 'self'; img-src 'self' data:; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; connect-src 'self' ws: wss:; object-src 'none'; base-uri 'none'"
  });
  if (req.method === 'HEAD') return res.end();
  fs.createReadStream(INDEX).on('error',()=>res.destroy()).pipe(res);
});
function generateCode(){
  const chars='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  for (let t=0;t<1000;t++) {
    let code='';for(let i=0;i<6;i++) code+=chars[crypto.randomInt(chars.length)];
    if (!rooms.has(code)) return code;
  }
  throw Error('no unused room codes');
}
function playersConnected(room){ return room.slots.filter(p=>p && p.conn && !p.conn.closed).length; }
function broadcast(room, msg){ for(const slot of room.slots) if(slot?.conn)sendJSON(slot.conn,msg); }
function roomStatus(room){
  const count=playersConnected(room);
  room.slots.forEach((slot,side)=>{if(slot?.conn)sendJSON(slot.conn,{type:'lobby',code:room.code,players:count,side,characters:room.types,phase:room.phase});});
}
function createRoom(){
  const code=generateCode();
  let room={code,slots:[null,null],types:[null,null],phase:'waiting',arena:null,updated:now(),pausedAt:0,missingSide:null,ready:[false,false]};
  rooms.set(code,room);return room;
}
function startMatch(room){
  if (room.slots.some(s=>!s?.conn) || !room.types.every(validChar)) return;
  room.arena=new Arena(room.types);room.phase='playing';room.updated=now();room.ready=[false,false];
  room.missingSide=null;room.pausedAt=0;room.endedSent=false;room.lastSentSeq=-1;
  room.slots.forEach((slot,side)=>{slot.lastInputAt=0;sendJSON(slot.conn,{type:'start',code:room.code,side,characters:room.types});});
  broadcast(room,{type:'state',data:room.arena.snapshot()});
}
function enterRoom(conn,room,character){
  if (conn.slot) return sendJSON(conn,{type:'error',message:'이미 방에 참가 중이에요.'});
  if (!validChar(character)) return sendJSON(conn,{type:'error',message:'올바른 캐릭터를 선택해 주세요.'});
  if (room.phase!=='waiting') return sendJSON(conn,{type:'error',message:'지금은 참가할 수 없는 방이에요.'});
  let side=room.slots.findIndex(x=>x===null);
  if(side<0)return sendJSON(conn,{type:'error',message:'방이 가득 찼어요.'});
  const token=crypto.randomBytes(24).toString('base64url');
  const slot={room,side,token,conn,lastInputAt:0};
  room.slots[side]=slot;room.types[side]=character;room.updated=now();conn.slot=slot;
  sendJSON(conn,{type:'session',code:room.code,token,side});
  roomStatus(room);
  if(playersConnected(room)===2)startMatch(room);
}
function terminateRoom(room,reason='expired'){
  rooms.delete(room.code);
  for(const slot of room.slots)if(slot){
    if(slot.conn){slot.conn.slot=null;sendJSON(slot.conn,{type:'room_closed',reason});}
    slot.conn=null;slot.token='';
  }
  room.slots=[null,null];room.arena=null;
}
function leave(conn, explicit=false){
  const slot=conn.slot;if(!slot)return;
  const room=slot.room,side=slot.side;
  if(slot.conn!==conn)return;
  conn.slot=null;
  slot.conn=null;slot.lastInputAt=0;
  if(!explicit){
    // Reserve the slot for a short time. Reconnection alone never forfeits immediately.
    if(room.phase==='playing' && room.arena && !room.arena.ended){
      room.phase='paused';room.pausedAt=now();room.missingSide=side;
      room.arena.setInput(side,{mx:0,my:0,fire:false,aimX:null,aimY:null,special:false,ult:false,dash:false});
      broadcast(room,{type:'paused',seconds:Math.ceil(RECONNECT_MS/1000)});
    } else if(room.phase==='paused') {
      room.pausedAt=Math.min(room.pausedAt||now(),now());
    }
    room.updated=now();return;
  }
  // Explicit leave revokes the reconnect token and frees the slot immediately.
  room.slots[side]=null;room.types[side]=null;room.ready[side]=false;
  slot.token='';room.updated=now();
  let opponent=room.slots[1-side];
  if(opponent){
    if(room.arena && !room.arena.ended){room.arena.ended=true;room.arena.winner=1-side;room.arena.endReason='FORFEIT';}
    room.phase='waiting';room.arena=null;room.pausedAt=0;room.missingSide=null;room.ready=[false,false];
    if(opponent.conn){sendJSON(opponent.conn,{type:'opponent_left',code:room.code,reason:'left'});}
    roomStatus(room);
  }else terminateRoom(room,'empty');
}
function resume(conn,code,token){
  const room=rooms.get(code);
  if(conn.slot)return sendJSON(conn,{type:'error',message:'이미 방에 있어요.'});
  const slot=room?.slots.find(s=>s && s.token===token);
  if(room?.phase==='paused' && now()-room.pausedAt>=RECONNECT_MS)return sendJSON(conn,{type:'resume_failed',message:'재접속 제한 시간이 지났어요.'});
  if(!slot || typeof token!=='string' || token.length<20)return sendJSON(conn,{type:'resume_failed',message:'유효한 재접속 정보가 없어요.'});
  if(slot.conn && !slot.conn.closed){
    // New browser connection is authoritative for this session. Old tab loses control.
    sendJSON(slot.conn,{type:'session_replaced'});
    slot.conn.slot=null;closeConn(slot.conn,1000);
  }
  slot.conn=conn;conn.slot=slot;slot.lastInputAt=0;slot.token=crypto.randomBytes(24).toString('base64url');room.updated=now();
  sendJSON(conn,{type:'session',code:room.code,token:slot.token,side:slot.side});
  roomStatus(room);
  if(room.phase==='paused' && playersConnected(room)===2){
    room.phase='playing';room.pausedAt=0;room.missingSide=null;
    broadcast(room,{type:'resumed'});
  }
  if(room.phase==='playing'||room.phase==='paused'){
    sendJSON(conn,{type:'start',code:room.code,side:slot.side,characters:room.types,resume:true});
    sendJSON(conn,{type:'state',data:room.arena.snapshot()});
    if(room.phase==='paused')sendJSON(conn,{type:'paused',seconds:Math.ceil(Math.max(0,RECONNECT_MS-(now()-room.pausedAt))/1000)});
  } else if(room.phase==='ended' && room.arena){
    sendJSON(conn,{type:'start',code:room.code,side:slot.side,characters:room.types,resume:true});
    sendJSON(conn,{type:'state',data:room.arena.snapshot()});
    sendJSON(conn,{type:'ended',winner:room.arena.winner,reason:room.arena.endReason});
  }
}
function expireReconnection(room){
  if(room.phase==='paused'){
    const disconnected=room.slots.map((s,i)=>s&&!s.conn?i:null).filter(v=>v!==null);
    const winner=disconnected.length===1?1-disconnected[0]:null;
    if(room.arena){room.arena.ended=true;room.arena.winner=winner;room.arena.endReason='DISCONNECT';}
    room.phase='ended';room.updated=now();room.pausedAt=0;
    broadcast(room,{type:'state',data:room.arena.snapshot()});
    broadcast(room,{type:'ended',winner,reason:'DISCONNECT'});
  }
  // Release disconnected slots when the grace period ends, retaining the opponent's slot for new join.
  let hasLeft=false;
  room.slots.forEach((s,i)=>{if(s&&!s.conn){s.token='';room.slots[i]=null;room.types[i]=null;room.ready[i]=false;hasLeft=true;}});
  if(!room.slots.some(Boolean))return terminateRoom(room,'empty');
  if(hasLeft){
    room.phase='waiting';room.arena=null;room.ready=[false,false];
    broadcast(room,{type:'opponent_left',code:room.code,reason:'timeout'});roomStatus(room);
  }
}
function bucket(conn,action){
  const t=performance.now();const b=action==='input'?conn.inputBucket:conn.commandBucket;
  const cap=action==='input'?45:12;
  const regen=action==='input'?35:4;
  b.tokens=Math.min(cap,b.tokens+(t-b.time)*regen/1000);b.time=t;
  if(b.tokens<1){packetsRejected++;return false;}
  b.tokens--;return true;
}
function handleMessage(conn,raw){
  let msg;
  try{msg=JSON.parse(raw);}catch{packetsRejected++;return;}
  if(!msg||typeof msg!=='object'||Array.isArray(msg)||typeof msg.type!=='string')return;
  const type=msg.type;
  if(!bucket(conn,type))return;
  if(type==='create'){
    if(conn.slot)return sendJSON(conn,{type:'error',message:'방에서 먼저 나가 주세요.'});
    if(rooms.size>=MAX_ROOMS)return sendJSON(conn,{type:'error',message:'서버의 방이 가득 찼어요.'});
    if(!validChar(msg.character))return sendJSON(conn,{type:'error',message:'캐릭터가 올바르지 않아요.'});
    return enterRoom(conn,createRoom(),msg.character);
  }
  if(type==='join'){
    if(typeof msg.code!=='string'|| !/^[A-HJ-NP-Z2-9]{6}$/.test(msg.code))return sendJSON(conn,{type:'error',message:'방 코드가 올바르지 않아요.'});
    let room=rooms.get(msg.code);if(!room)return sendJSON(conn,{type:'error',message:'방을 찾을 수 없어요.'});
    return enterRoom(conn,room,msg.character);
  }
  if(type==='resume'){
    if(typeof msg.code!=='string'||typeof msg.token!=='string')return sendJSON(conn,{type:'resume_failed',message:'복구 정보가 올바르지 않아요.'});
    return resume(conn,msg.code,msg.token);
  }
  if(type==='leave')return leave(conn,true);
  const slot=conn.slot;if(!slot||slot.conn!==conn)return;
  const room=slot.room;
  if(type==='input' && room.phase==='playing' && room.arena && !room.arena.ended){
    let d=msg.data;
    if(!d||typeof d!=='object'||Array.isArray(d))return;
    // Strict validation: never accept position, HP, damage or cooldown fields from the client.
    const validNumber=x=>typeof x==='number'&&Number.isFinite(x);
    if(!validNumber(d.mx)||!validNumber(d.my)||Math.abs(d.mx)>3||Math.abs(d.my)>3)return;
    if(!validNumber(d.aimX)||!validNumber(d.aimY)||d.aimX<-100||d.aimX>1000||d.aimY<-100||d.aimY>700)return;
    if(['fire','special','ult','dash'].some(k=>typeof d[k]!=='boolean'))return;
    room.arena.setInput(slot.side,d);slot.lastInputAt=now();
    return;
  }
  if(type==='rematch' && room.phase==='ended' && room.slots.every(s=>s?.conn)){
    room.ready[slot.side]=true;
    broadcast(room,{type:'ready',side:slot.side,ready:room.ready});
    if(room.ready.every(Boolean))startMatch(room);
  }
}
function closeConn(conn,code=1001){
  if(conn.closed)return;
  conn.closed=true;sockets.delete(conn);
  const count=(ipCounts.get(conn.ip)||1)-1;if(count>0)ipCounts.set(conn.ip,count);else ipCounts.delete(conn.ip);
  leave(conn,false);
  if(!conn.socket.destroyed){
    try{sendRaw(conn,8,Buffer.from([code>>8,code&255]));}catch{}
    conn.socket.destroy();
  }
}
function onSocket(socket,ip){
  const conn={socket,ip,closed:false,slot:null,buf:Buffer.alloc(0),lastPong:now(),inputBucket:{time:performance.now(),tokens:45},commandBucket:{time:performance.now(),tokens:12}};
  sockets.add(conn);ipCounts.set(ip,(ipCounts.get(ip)||0)+1);
  socket.on('data',chunk=>{
    if(conn.closed)return;
    if(conn.buf.length+chunk.length>MAX_FRAME*2+256)return closeConn(conn,1009);
    conn.buf=Buffer.concat([conn.buf,chunk]);
    let processed=0;
    while(conn.buf.length>=2){
      if(++processed>64)return closeConn(conn,1008);
      const b=conn.buf;
      const opcode=b[0]&15,fin=(b[0]&128)!==0,rsv=b[0]&0x70;
      const masked=(b[1]&128)!==0;
      let len=b[1]&127,ofs=2;
      if(len===126){if(b.length<4)return;len=b.readUInt16BE(2);ofs=4;}
      if(len===127){if(b.length<10)return;let big=b.readBigUInt64BE(2);if(big>BigInt(MAX_FRAME))return closeConn(conn,1009);len=Number(big);ofs=10;}
      if(!masked||!fin||rsv||len>MAX_FRAME)return closeConn(conn,1002);
      if(b.length<ofs+4+len)return;
      const mask=b.subarray(ofs,ofs+4);
      let payload=Buffer.from(b.subarray(ofs+4,ofs+4+len));
      conn.buf=b.subarray(ofs+4+len);
      for(let i=0;i<payload.length;i++)payload[i]^=mask[i%4];
      if(opcode===8)return closeConn(conn,1000);
      if(opcode===9){sendRaw(conn,10,payload);continue;}
      if(opcode===10){conn.lastPong=now();continue;}
      if(opcode!==1)return closeConn(conn,1003);
      try{handleMessage(conn,payload.toString('utf8'));}catch(err){console.error('Message failure:',err);sendJSON(conn,{type:'error',message:'요청 처리에 실패했어요.'});}
    }
  });
  socket.on('close',()=>closeConn(conn));
  socket.on('error',()=>closeConn(conn));
}
server.on('upgrade',(req,socket,head)=>{
  socket.on('error',()=>socket.destroy());
  if(closing||sockets.size>=MAX_CONNECTIONS){socket.destroy();return;}
  const ip=req.socket.remoteAddress||'unknown';
  if((ipCounts.get(ip)||0)>=perIpLimit){socket.destroy();return;}
  if(req.url!=='/ws'||req.method!=='GET'||req.headers.upgrade?.toLowerCase()!=='websocket'||!String(req.headers.connection||'').toLowerCase().split(',').map(s=>s.trim()).includes('upgrade'))return socket.destroy();
  if(req.headers['sec-websocket-version']!=='13')return socket.destroy();
  const key=req.headers['sec-websocket-key'];
  if(typeof key!=='string'||!/^[A-Za-z0-9+/]{22}==$/.test(key)||Buffer.from(key,'base64').length!==16)return socket.destroy();
  // Browser requests must be same-origin. CLI WebSockets may omit Origin.
  if(req.headers.origin){
    try{
      const origin=new URL(req.headers.origin);
      const allowed=process.env.PUBLIC_ORIGIN ? new URL(process.env.PUBLIC_ORIGIN).origin : null;
      if(allowed?origin.origin!==allowed:origin.host!==req.headers.host|| !['http:','https:'].includes(origin.protocol))return socket.destroy();
    }catch{return socket.destroy();}
  }
  const accept=crypto.createHash('sha1').update(key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
  socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: '+accept+'\r\n\r\n');
  onSocket(socket,ip);
  if(head?.length)socket.emit('data',head);
});
// Fixed-step simulation at 60Hz; networking snapshots at 20Hz. Monotonic frame clock.
let prev=performance.now(),acc=0,netAcc=0;
const loop=setInterval(()=>{
  const tm=performance.now(),step=1000/60;
  acc+=Math.min(100,Math.max(0,tm-prev));netAcc+=Math.min(100,Math.max(0,tm-prev));prev=tm;
  let steps=0;
  while(acc>=step&&steps++<6){
    for(const room of rooms.values())if(room.phase==='playing'&&room.arena){
      for(const slot of room.slots)if(slot?.conn&&now()-slot.lastInputAt>250){
        room.arena.setInput(slot.side,{mx:0,my:0,aimX:null,aimY:null,fire:false,special:false,ult:false,dash:false});
      }
      room.arena.tick(step);
      if(room.arena.ended){room.phase='ended';room.updated=now();}
    }
    acc-=step;
  }
  if(netAcc>=50){
    netAcc%=50;
    for(const room of rooms.values())if(room.arena&&(room.phase==='playing'||room.phase==='ended')){
      if(room.phase==='playing'||room.lastSentSeq!==room.arena.seq){
        broadcast(room,{type:'state',data:room.arena.snapshot()});room.lastSentSeq=room.arena.seq;
        if(room.phase==='ended' && !room.endedSent){room.endedSent=true;broadcast(room,{type:'ended',winner:room.arena.winner,reason:room.arena.endReason});}
      }
    }
  }
},1000/60);
let lastPing=0;
const upkeep=setInterval(()=>{
  const t=now();
  for(const room of rooms.values()){
    if(room.phase==='paused' && t-room.pausedAt>=RECONNECT_MS)expireReconnection(room);
    else if(room.phase==='waiting' && room.slots.some(s=>s&&!s.conn) && t-room.updated>=RECONNECT_MS)expireReconnection(room);
    else if(room.phase==='ended' && room.slots.some(s=>s&&!s.conn) && t-room.updated>=RECONNECT_MS)expireReconnection(room);
    const deadline=room.phase==='waiting'?WAIT_MS:room.phase==='ended'?ENDED_MS:PLAY_MS;
    if(t-room.updated>deadline)terminateRoom(room,'expired');
  }
  if(t-lastPing>=15000){
    lastPing=t;
    for(const c of [...sockets]){
      if(t-c.lastPong>45000){closeConn(c,1001);continue;}
      sendRaw(c,9,Buffer.from('sa'));
    }
  }
},1000);
loop.unref();upkeep.unref();
function shutdown(){if(closing)return;closing=true;clearInterval(loop);clearInterval(upkeep);for(const room of [...rooms.values()])terminateRoom(room,'server_shutdown');for(const c of [...sockets])closeConn(c);server.close(()=>process.exit(0));setTimeout(()=>process.exit(0),2500).unref();}
process.on('SIGTERM',shutdown);process.on('SIGINT',shutdown);
if(require.main===module)server.listen(PORT,HOST,()=>console.log(`SHADOW ARENA v18 server ready http://localhost:${server.address().port} (rooms=${MAX_ROOMS}, reconnect=${RECONNECT_MS/1000}s)`));
module.exports={server,rooms,sockets};
